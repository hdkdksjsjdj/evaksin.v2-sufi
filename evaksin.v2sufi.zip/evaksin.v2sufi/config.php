<!--Membuat sambungan ke db-->
<?php

$host ="localhost";
$user = "root";
$pass = "";
$dbname = "evaksin";

$conn =mysqli_connect($host,$user,$pass,$dbname);

if(!$conn) {
	echo "not connected";
}

else {
	echo "";
}


?>

